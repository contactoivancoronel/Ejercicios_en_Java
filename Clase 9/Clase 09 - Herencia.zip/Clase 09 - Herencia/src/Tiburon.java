
public class Tiburon extends Pez {

	
	public void comerGente() {
		System.out.println("El tiburon consume placidamente una persona");		
	}
	
	public void asustar() {
		System.out.println("El tiburon asusta a todos alrededor");
		
	}

	public Tiburon(String color) {
		super(color);
	}
	
	
	
}
