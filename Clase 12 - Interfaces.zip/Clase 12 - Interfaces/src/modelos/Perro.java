package modelos;

public class Perro extends Animal {

	@Override
	public void hacerRuido() {
		System.out.println("Guau");
		
	}

	@Override
	public void mostrar() {
		// TODO Auto-generated method stub
		
	}

	
	
}
