package modelos;

public abstract class FiguraGeometrica {

	public abstract double getArea();
	public abstract double getPerimetro();
	

}
