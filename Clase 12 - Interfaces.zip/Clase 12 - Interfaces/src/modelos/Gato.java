package modelos;

import java.io.Serializable;

public final class Gato extends Animal implements Serializable {

	private static final long serialVersionUID = -646798869537504348L;

	@Override
	public void mostrar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hacerRuido() {
		// TODO Auto-generated method stub

	}
	

}
