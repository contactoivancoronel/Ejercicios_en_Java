
public class Main {

	/*
primitivo	Envoltorio
-----------------------------
boolean		Boolean
byte		Byte
char		Character
short		Short
int			Integer
long		Long
float		Float
double		Double
	 
	*/
	
	public static void main(String[] args) {
		boolean booleanPrimitivo = true;
		Boolean booleanEnvoltorio = true;
		
		int enteroPrimitivo = 6;
		Integer enteroEnvoltorio = 6;
		
		
		char caracterPrimitivo = 'a';
		Character caracterEnvoltorio = 'a';
		
		

		System.out.println(booleanPrimitivo);
		System.out.println(booleanEnvoltorio);
		
		
		
		
	}

}
