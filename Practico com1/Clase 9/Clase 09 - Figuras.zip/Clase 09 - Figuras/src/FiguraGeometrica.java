
public abstract class FiguraGeometrica {

		
	//Los metodos abstractos van a tener que 
	//ser definidos en los hijos no abstractos
	public abstract double getPerimetro() ;
	public abstract double getArea();
	
	
	
}
