import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numero;
		
		int vector[] = new int[5] ;
		
		

		//scanf("%d", &a);
		int a = sc.nextInt();
		
		double b = sc.nextDouble();

		System.out.println("El numero ingresado es: "+  a );
		System.out.println("El numero ingresado es: "+  b  ) ;

	}

}
