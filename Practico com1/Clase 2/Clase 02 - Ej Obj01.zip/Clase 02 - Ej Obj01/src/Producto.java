
public class Producto {
	public double costo;
	public double precio;
	public String codigo;
	public double cantidad;
	
	
	
}
/*
1.    En una tienda donde solo hay 10 productos se desea 
calcular el total de ganancia que produjo dicho negocio 
este mes. Para ello se cuenta por producto con: 
	Precio del Costo, precio de venta, c�digo 
	y cantidad vendida en ese periodo. Realizar
	programa que permita calcular las 
	Ganancias de la Tienda.
*/