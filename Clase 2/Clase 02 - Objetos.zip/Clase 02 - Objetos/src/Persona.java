
public class Persona {
	public double altura;
	public double peso;
	public String nombre;
	public int edad;
	
	public double sumar(double a, double b) {
		return a + b;
	}
	
	public void saludar() {
		System.out.println("Hola!");
	}
	
	public void decir(String texto) {
		System.out.println(texto);
	}
}
