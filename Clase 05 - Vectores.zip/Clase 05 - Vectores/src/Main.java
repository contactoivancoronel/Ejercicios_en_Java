
public class Main {

	public static void main(String[] args) {
		String[] textos = {"Pepe","Maria","Gabriel"};
		textos = new String[6];
		
		for (int i = 0; i < textos.length; i++) {
			System.out.println( textos[i]);
			
		}
		
		
		

	}

}
