
public class Perro {

	public int edad;
	
	private double peso;
	
	public void mostrarPeso() {
		System.out.println( this.peso  );
		
	}
	
	private void saludar() {
		System.out.println("Hola!");
	}
	
}
