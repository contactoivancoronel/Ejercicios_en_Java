
public class Balanza {

	public void pesar(Perro perro) {
		perro.mostrarPeso();
	}
	
	
}
