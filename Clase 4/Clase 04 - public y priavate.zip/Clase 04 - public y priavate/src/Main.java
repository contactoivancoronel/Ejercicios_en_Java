
public class Main {

	public static void main(String[] args) {
		
		Perro perri = new Perro();
		
		perri.mostrarPeso();
	//No se puede ya que es privado
	//	perri.peso = 5;
		
		

	}

}
