
public class Main {

	public static void main(String[] args) {
		
		Perro perro1, perro2, perro3, perro4, perro5;
		perro1 = new Perro();
		perro1.setEdad(12);
		
		

	}

}
